package com.mybatis.kdt9.controller;

import com.mybatis.kdt9.domain.Board;
import com.mybatis.kdt9.dto.BoardDTO;
import com.mybatis.kdt9.service.BoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class BoardController {
    @Autowired
    private BoardService boardService;

    @GetMapping("/board")
    public String getBoards(Model model) {
        List<BoardDTO> list = boardService.getBoardAll();
        model.addAttribute("list", list);
        return "board";
    }

    @GetMapping("/board/search")
    public void searchBoard() {

    }

    @PostMapping("/board")
    @ResponseBody
    public void insertBoard(@RequestBody Board board) {
        boardService.insertBoard(board);
    }

    @PatchMapping("/board")
    public void patchBoard() {

    }

    @DeleteMapping("/board")
    public void deleteBoard() {

    }
}
