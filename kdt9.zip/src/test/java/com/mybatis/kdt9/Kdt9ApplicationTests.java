package com.mybatis.kdt9;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Kdt9ApplicationTests {

	@Test
	void contextLoads() {
	}

}
